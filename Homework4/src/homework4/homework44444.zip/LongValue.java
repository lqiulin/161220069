package homework4;

public class LongValue {
	public long value;

	public LongValue(long i) {
		value = i;
	}
}
