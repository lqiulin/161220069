package homework4;

public class IntValue {
	public int value;

	public IntValue(int i) {
		value = i;
	}
}
